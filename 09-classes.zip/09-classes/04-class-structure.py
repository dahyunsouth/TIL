class Circle:
    pi = 3.14

    # 생성자 메서드
    def __init__(self, radius):     # 이 radius와
        self.radius = radius        # 우항의 radius는 같음, 좌항의 radius는 다름


# 인스턴스 생성
c1 = Circle(1)
c2 = Circle(5)

# 인스턴스 변수(속성)
print(c1.radius)
print(c2.radius)

# 클래스 변수(속성)
print(c1.pi)
print(c2.pi)