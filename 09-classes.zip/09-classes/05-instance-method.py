class Counter:
    def __init__(self):
        self.count = 0

    def increment(self):



c = Counter()
print(c.count) # 0
c.increment()
print(c.count)

c2 = Counter()
c.increment()
print(c2.count) #0  # c2는 increment 메서드 호출한 적 없음


# 강의 다시보기
# line 2, 3도 큰 틀에서는 인스턴스 메서드
# 인스턴스 메서드는 고민하지 말고 소괄호 안에 self 넣으셈
    # 문법적으로 그럴 수밖에 없음