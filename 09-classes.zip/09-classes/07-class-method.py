# 강의 다시보기

class Person:
    population = 0

    def __init__(self, name):               # 인스턴스 메서드
        self.name = name                    # 인스턴스 메서드
        Person.increase_population()        # 인스턴스 메서드

    @classmethod                            # 클래스 메서드
    def increase_population(cls):           # 클래스 메서드
        cls.population += 1                 # 클래스 메서드

person1 = Person('Alice')
person2 = Person('Bob')
print(Person.population)  # 2


Person.increase_population()
print(Person.population) # 3