class MathUtils:
    @staticmethod
    def add(a, b):
        return a + b


print(MathUtils.add(1, 2))  # 3
